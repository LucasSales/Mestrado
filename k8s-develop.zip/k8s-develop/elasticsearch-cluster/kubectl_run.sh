#!/bin/bash

#RUNNING:

# First create the serviceaccount:
kubectl create serviceaccount sa-elasticsearch

# Create the rabc:
kubectl create -f rabc.yml

# Create the services:
kubectl create -f services.yml

# Create the persistentVolume:
kubectl create -f elasticsearch-data-pv.yml

# Deploy the stateful-set for the data node:
kubectl create -f statefulset-data.yml

# Deploy the master node deployment:
kubectl create -f master-deployment.yml

# Deploy the client/ingest nodes:
kubectl create -f client-deployment.yml

