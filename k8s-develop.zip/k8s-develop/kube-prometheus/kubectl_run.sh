#!/bin/bash

kubectl create -f manifests/

echo "Waiting confirmation of resources creationg..."

until kubectl get customresourcedefinitions servicemonitors.monitoring.coreos.com ; do date; sleep 1; echo ""; done
until kubectl get servicemonitors --all-namespaces ; do date; sleep 1; echo ""; done

echo "Applying changes"
kubectl apply -f manifests/ # This command sometimes may need to be done twice (to workaround a race condition).
