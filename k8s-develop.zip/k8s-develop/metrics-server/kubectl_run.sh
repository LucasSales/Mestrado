#!/bin/bash

kubectl apply -f deploy/
